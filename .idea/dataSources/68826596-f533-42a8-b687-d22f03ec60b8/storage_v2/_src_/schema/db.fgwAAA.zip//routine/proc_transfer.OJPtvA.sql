create
    definer = root@localhost procedure proc_transfer(IN id_from int, IN id_to int, IN money int)
begin
update tb_account set balance=balance+money where id=id_to;
update tb_account set balance=balance-money where id=id_from;
end;

